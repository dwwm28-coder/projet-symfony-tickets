<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

final class Version20261029090000 extends AbstractMigration
{
    public function getDescription(): string { return 'Crée les tables utilisateurs, catégories, états et tickets.'; }

    public function up(Schema $schema): void
    {
        $this->addSql('CREATE TABLE user_account (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, email VARCHAR(180) NOT NULL, roles CLOB NOT NULL, password VARCHAR(255) NOT NULL, full_name VARCHAR(100) NOT NULL)');
        $this->addSql('CREATE UNIQUE INDEX uniq_user_email ON user_account (email)');
        $this->addSql('CREATE TABLE category (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name VARCHAR(80) NOT NULL)');
        $this->addSql('CREATE UNIQUE INDEX uniq_category_name ON category (name)');
        $this->addSql('CREATE TABLE ticket_status (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name VARCHAR(40) NOT NULL, closed BOOLEAN NOT NULL)');
        $this->addSql('CREATE UNIQUE INDEX uniq_status_name ON ticket_status (name)');
        $this->addSql('CREATE TABLE support_ticket (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, category_id INT NOT NULL, status_id INT NOT NULL, assignee_id INT DEFAULT NULL, author_email VARCHAR(180) NOT NULL, opened_at DATETIME NOT NULL, closed_at DATETIME DEFAULT NULL, description CLOB NOT NULL, CONSTRAINT FK_TICKET_CATEGORY FOREIGN KEY (category_id) REFERENCES category (id) ON DELETE RESTRICT, CONSTRAINT FK_TICKET_STATUS FOREIGN KEY (status_id) REFERENCES ticket_status (id) ON DELETE RESTRICT, CONSTRAINT FK_TICKET_ASSIGNEE FOREIGN KEY (assignee_id) REFERENCES user_account (id) ON DELETE SET NULL)');
        $this->addSql('CREATE INDEX IDX_TICKET_CATEGORY ON support_ticket (category_id)');
        $this->addSql('CREATE INDEX IDX_TICKET_STATUS ON support_ticket (status_id)');
        $this->addSql('CREATE INDEX IDX_TICKET_ASSIGNEE ON support_ticket (assignee_id)');
    }

    public function down(Schema $schema): void
    {
        $this->addSql('DROP TABLE support_ticket');
        $this->addSql('DROP TABLE ticket_status');
        $this->addSql('DROP TABLE category');
        $this->addSql('DROP TABLE user_account');
    }
}
