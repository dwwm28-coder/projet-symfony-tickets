# Projet Symfony — Portail de tickets

Application locale pour recevoir et suivre les tickets clients. Le dépôt ne contient ni mot de passe, ni accès à une base distante. La base est SQLite et le fichier de données local (`var/data.db`) n’est pas versionné.

## Prérequis

- PHP 8.2+ avec `ctype`, `iconv`, `mbstring` et `pdo_sqlite` activés ;
- Composer 2 ;
- Symfony CLI (facultatif, pour le serveur local).

## Installation

Dans PowerShell, depuis la racine du projet. Avec XAMPP installé dans `C:\xampp`, la première commande sélectionne son PHP pour la fenêtre PowerShell en cours :

```powershell
$env:Path = "C:\xampp\php;" + $env:Path
composer install
symfony console doctrine:migrations:migrate --no-interaction
symfony console doctrine:fixtures:load --no-interaction
symfony console app:create-admin
symfony server:start
```

Ouvrir ensuite `http://127.0.0.1:8000`. Si XAMPP est installé ailleurs, remplacer `C:\xampp\php` par son dossier PHP. Sans XAMPP, activer `pdo_sqlite` dans le `php.ini` utilisé par le terminal.

La commande `app:create-admin` demande l’adresse e-mail, le nom et un mot de passe (saisie masquée). Le mot de passe est hashé avant enregistrement, n’est jamais stocké dans les fichiers du projet et n’est pas inclus dans GitHub. L’URL locale s’affiche après le démarrage du serveur.

Si Symfony CLI n’est pas installé, démarrer PHP avec `php -S 127.0.0.1:8000 -t public`, puis ouvrir `http://127.0.0.1:8000`.

## Fonctionnalités

- Page publique avec formulaire de ticket : e-mail, description de 20 à 250 caractères et catégorie ;
- date d’ouverture créée automatiquement ;
- connexion et déconnexion du personnel et de l’administrateur ;
- liste et détail des tickets ;
- personnel limité à la consultation et au changement du statut ;
- administrateur habilité à modifier les tickets et à gérer les catégories, les statuts et les comptes du personnel/responsables ;
- date de clôture mise à jour automatiquement quand le statut sélectionné est configuré comme clôturant ;
- contrôles serveur avec Symfony Validator et protection CSRF des formulaires.

## Migrations et fixtures

Les changements de schéma sont décrits dans `migrations/`. Les catégories, statuts et un ticket d’essai sont définis dans `src/DataFixtures/AppFixtures.php`. Les fixtures sont réinitialisables : Doctrine affiche une confirmation, car le chargement supprime les données existantes.

## Configuration locale et sécurité

`.env` contient uniquement des valeurs non secrètes pour le développement (SQLite local). Pour une configuration particulière, créer `.env.local`, ignoré par Git. Ne pas y copier de mots de passe, clés ou données réelles dans le dépôt. Le compte administrateur se crée localement avec la commande dédiée.
