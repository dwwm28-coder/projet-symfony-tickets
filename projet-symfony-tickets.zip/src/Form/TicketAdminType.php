<?php

namespace App\Form;

use App\Entity\Category;
use App\Entity\Ticket;
use App\Entity\TicketStatus;
use App\Entity\User;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class TicketAdminType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder->add('authorEmail', EmailType::class, ['label' => 'E-mail du client'])
            ->add('description', TextareaType::class, ['label' => 'Description'])
            ->add('category', EntityType::class, ['class' => Category::class, 'choice_label' => 'name', 'label' => 'Catégorie'])
            ->add('status', EntityType::class, ['class' => TicketStatus::class, 'choice_label' => 'name', 'label' => 'État'])
            ->add('assignee', EntityType::class, ['class' => User::class, 'choice_label' => 'fullName', 'placeholder' => 'Non attribué', 'required' => false, 'label' => 'Responsable']);
    }
    public function configureOptions(OptionsResolver $resolver): void { $resolver->setDefaults(['data_class' => Ticket::class]); }
}
