<?php

namespace App\Form;

use App\Entity\Category;
use App\Entity\Ticket;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class TicketCreateType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder->add('authorEmail', EmailType::class, ['label' => 'Votre adresse e-mail'])
            ->add('category', EntityType::class, ['class' => Category::class, 'choice_label' => 'name', 'placeholder' => 'Choisir une catégorie', 'label' => 'Catégorie'])
            ->add('description', TextareaType::class, ['label' => 'Description', 'attr' => ['rows' => 5, 'minlength' => 20, 'maxlength' => 250, 'placeholder' => 'Décrivez votre demande en 20 à 250 caractères…']]);
    }
    public function configureOptions(OptionsResolver $resolver): void { $resolver->setDefaults(['data_class' => Ticket::class]); }
}
