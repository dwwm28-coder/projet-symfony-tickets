<?php

namespace App\Form;

use App\Entity\User;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class StaffType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder->add('fullName', TextType::class, ['label' => 'Nom complet'])
            ->add('email', EmailType::class, ['label' => 'Adresse e-mail'])
            ->add('roles', ChoiceType::class, ['label' => 'Rôle', 'choices' => ['Personnel' => 'ROLE_STAFF', 'Administrateur' => 'ROLE_ADMIN'], 'expanded' => true, 'multiple' => true]);
        if ($options['password_required']) {
            $builder->add('plainPassword', PasswordType::class, ['mapped' => false, 'label' => 'Mot de passe temporaire', 'constraints' => []]);
        }
    }
    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults(['data_class' => User::class, 'password_required' => false]);
        $resolver->setAllowedTypes('password_required', 'bool');
    }
}
