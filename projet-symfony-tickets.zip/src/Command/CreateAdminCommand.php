<?php

namespace App\Command;

use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[AsCommand(name: 'app:create-admin', description: 'Crée un compte administrateur local en demandant ses identifiants.')]
class CreateAdminCommand extends Command
{
    public function __construct(private readonly EntityManagerInterface $em, private readonly UserPasswordHasherInterface $hasher, private readonly ValidatorInterface $validator)
    {
        parent::__construct();
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $email = mb_strtolower(trim((string) $io->ask('Adresse e-mail de l’administrateur')));
        $name = trim((string) $io->ask('Nom complet'));
        $password = (string) $io->askHidden('Mot de passe (12 caractères minimum)');

        if (mb_strlen($password) < 12) {
            $io->error('Le mot de passe doit contenir au moins 12 caractères.');
            return Command::INVALID;
        }
        if ($this->em->getRepository(User::class)->findOneBy(['email' => $email])) {
            $io->error('Un compte utilise déjà cette adresse e-mail.');
            return Command::INVALID;
        }

        $admin = (new User())->setEmail($email)->setFullName($name)->setRoles(['ROLE_ADMIN']);
        $admin->setPassword($this->hasher->hashPassword($admin, $password));
        $violations = $this->validator->validate($admin);
        if (count($violations) > 0) {
            foreach ($violations as $violation) $io->writeln('<error>'.$violation->getMessage().'</error>');
            return Command::INVALID;
        }

        $this->em->persist($admin);
        $this->em->flush();
        $io->success('Le compte administrateur local a été créé. Aucun mot de passe n’a été écrit dans le projet.');
        return Command::SUCCESS;
    }
}
