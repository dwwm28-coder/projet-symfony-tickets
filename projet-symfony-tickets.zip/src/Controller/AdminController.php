<?php

namespace App\Controller;

use App\Entity\Category;
use App\Entity\TicketStatus;
use App\Entity\User;
use App\Form\CategoryType;
use App\Form\StaffType;
use App\Form\TicketStatusFormType;
use App\Repository\CategoryRepository;
use App\Repository\TicketStatusRepository;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[IsGranted('ROLE_ADMIN')]
#[Route('/admin')]
class AdminController extends AbstractController
{
    #[Route('', name: 'app_admin_index')]
    public function index(CategoryRepository $categories, TicketStatusRepository $statuses, UserRepository $users): Response
    {
        return $this->render('admin/index.html.twig', ['categories' => $categories->findBy([], ['name' => 'ASC']), 'statuses' => $statuses->findBy([], ['id' => 'ASC']), 'users' => $users->findBy([], ['fullName' => 'ASC'])]);
    }

    #[Route('/categories/nouvelle', name: 'app_admin_category_new', methods: ['GET', 'POST'])]
    #[Route('/categories/{id}/modifier', name: 'app_admin_category_edit', methods: ['GET', 'POST'])]
    public function category(?Category $category, Request $request, EntityManagerInterface $em): Response
    {
        $category ??= new Category();
        $form = $this->createForm(CategoryType::class, $category)->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($category); $em->flush(); $this->addFlash('success', 'Catégorie enregistrée.');
            return $this->redirectToRoute('app_admin_index');
        }
        return $this->render('admin/form.html.twig', ['form' => $form, 'title' => $category->getId() ? 'Modifier une catégorie' : 'Nouvelle catégorie']);
    }

    #[Route('/etats/nouveau', name: 'app_admin_status_new', methods: ['GET', 'POST'])]
    #[Route('/etats/{id}/modifier', name: 'app_admin_status_edit', methods: ['GET', 'POST'])]
    public function status(?TicketStatus $status, Request $request, EntityManagerInterface $em): Response
    {
        $status ??= new TicketStatus();
        $form = $this->createForm(TicketStatusFormType::class, $status)->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($status); $em->flush(); $this->addFlash('success', 'État enregistré.');
            return $this->redirectToRoute('app_admin_index');
        }
        return $this->render('admin/form.html.twig', ['form' => $form, 'title' => $status->getId() ? 'Modifier un état' : 'Nouvel état']);
    }

    #[Route('/responsables/nouveau', name: 'app_admin_user_new', methods: ['GET', 'POST'])]
    #[Route('/responsables/{id}/modifier', name: 'app_admin_user_edit', methods: ['GET', 'POST'])]
    public function user(?User $user, Request $request, EntityManagerInterface $em, UserPasswordHasherInterface $hasher): Response
    {
        $user ??= new User();
        $isNew = $user->getId() === null;
        $form = $this->createForm(StaffType::class, $user, ['password_required' => $isNew])->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $plainPassword = $form->has('plainPassword') ? (string) $form->get('plainPassword')->getData() : '';
            if ($isNew && mb_strlen($plainPassword) < 12) {
                $form->get('plainPassword')->addError(new FormError('Le mot de passe doit contenir au moins 12 caractères.'));
            } else {
                if ($plainPassword !== '') $user->setPassword($hasher->hashPassword($user, $plainPassword));
                $em->persist($user); $em->flush(); $this->addFlash('success', 'Membre enregistré.');
                return $this->redirectToRoute('app_admin_index');
            }
        }
        return $this->render('admin/form.html.twig', ['form' => $form, 'title' => $isNew ? 'Ajouter un responsable' : 'Modifier un membre']);
    }
}
