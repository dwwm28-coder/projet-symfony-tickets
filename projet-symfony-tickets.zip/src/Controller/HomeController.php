<?php

namespace App\Controller;

use App\Entity\Ticket;
use App\Form\TicketCreateType;
use App\Repository\TicketStatusRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class HomeController extends AbstractController
{
    #[Route('/', name: 'app_home', methods: ['GET', 'POST'])]
    public function index(Request $request, EntityManagerInterface $em, TicketStatusRepository $statuses): Response
    {
        $ticket = new Ticket();
        $form = $this->createForm(TicketCreateType::class, $ticket)->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $status = $statuses->findOneBy(['name' => 'Nouveau']) ?? $statuses->findOneBy([]);
            if (!$status) {
                $this->addFlash('danger', 'Aucun état n’est configuré. Contactez l’administrateur.');
                return $this->redirectToRoute('app_home');
            }
            $ticket->setStatus($status)->setOpenedAt(new \DateTimeImmutable());
            $em->persist($ticket);
            $em->flush();
            $this->addFlash('success', 'Votre ticket a bien été transmis à notre équipe.');
            return $this->redirectToRoute('app_home');
        }
        return $this->render('home/index.html.twig', ['form' => $form]);
    }
}
