<?php

namespace App\Controller;

use App\Entity\Ticket;
use App\Form\StatusType;
use App\Form\TicketAdminType;
use App\Repository\TicketRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[IsGranted('ROLE_STAFF')]
#[Route('/tickets')]
class TicketController extends AbstractController
{
    #[Route('', name: 'app_ticket_index', methods: ['GET'])]
    public function index(TicketRepository $repository): Response
    {
        return $this->render('ticket/index.html.twig', ['tickets' => $repository->findLatest()]);
    }

    #[Route('/{id}', name: 'app_ticket_show', requirements: ['id' => '\\d+'], methods: ['GET', 'POST'])]
    public function show(Ticket $ticket, Request $request, EntityManagerInterface $em): Response
    {
        $isAdmin = $this->isGranted('ROLE_ADMIN');
        $form = $this->createForm($isAdmin ? TicketAdminType::class : StatusType::class, $ticket)->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $this->syncClosingDate($ticket);
            $em->flush();
            $this->addFlash('success', 'Le ticket a été mis à jour.');
            return $this->redirectToRoute('app_ticket_show', ['id' => $ticket->getId()]);
        }
        return $this->render('ticket/show.html.twig', ['ticket' => $ticket, 'form' => $form, 'is_admin' => $isAdmin]);
    }

    #[Route('/nouveau', name: 'app_ticket_new', methods: ['GET', 'POST'])]
    #[IsGranted('ROLE_ADMIN')]
    public function new(Request $request, EntityManagerInterface $em): Response
    {
        $ticket = (new Ticket())->setOpenedAt(new \DateTimeImmutable());
        $form = $this->createForm(TicketAdminType::class, $ticket)->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $this->syncClosingDate($ticket);
            $em->persist($ticket);
            $em->flush();
            $this->addFlash('success', 'Ticket créé.');
            return $this->redirectToRoute('app_ticket_index');
        }
        return $this->render('ticket/edit.html.twig', ['form' => $form, 'title' => 'Créer un ticket']);
    }

    private function syncClosingDate(Ticket $ticket): void
    {
        if ($ticket->getStatus()?->isClosed()) {
            $ticket->setClosedAt($ticket->getClosedAt() ?? new \DateTimeImmutable());
        } else {
            $ticket->setClosedAt(null);
        }
    }
}
