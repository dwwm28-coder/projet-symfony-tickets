<?php

namespace App\Repository;

use App\Entity\Ticket;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class TicketRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry) { parent::__construct($registry, Ticket::class); }

    public function findLatest(): array
    {
        return $this->createQueryBuilder('ticket')
            ->leftJoin('ticket.category', 'category')->addSelect('category')
            ->leftJoin('ticket.status', 'status')->addSelect('status')
            ->leftJoin('ticket.assignee', 'assignee')->addSelect('assignee')
            ->orderBy('ticket.openedAt', 'DESC')->getQuery()->getResult();
    }
}
