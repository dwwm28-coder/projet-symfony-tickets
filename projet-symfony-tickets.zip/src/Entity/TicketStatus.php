<?php

namespace App\Entity;

use App\Repository\TicketStatusRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

#[ORM\Entity(repositoryClass: TicketStatusRepository::class)]
#[ORM\UniqueConstraint(name: 'uniq_status_name', columns: ['name'])]
#[UniqueEntity(fields: ['name'], message: 'Cet état existe déjà.')]
class TicketStatus
{
    #[ORM\Id, ORM\GeneratedValue, ORM\Column]
    private ?int $id = null;
    #[ORM\Column(length: 40)]
    #[Assert\NotBlank, Assert\Length(max: 40)]
    private string $name = '';
    #[ORM\Column]
    private bool $closed = false;
    public function getId(): ?int { return $this->id; }
    public function getName(): string { return $this->name; }
    public function setName(string $name): static { $this->name = trim($name); return $this; }
    public function isClosed(): bool { return $this->closed; }
    public function setClosed(bool $closed): static { $this->closed = $closed; return $this; }
    public function __toString(): string { return $this->name; }
}
