<?php

namespace App\Entity;

use App\Repository\TicketRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

#[ORM\Entity(repositoryClass: TicketRepository::class)]
#[ORM\Table(name: 'support_ticket')]
class Ticket
{
    #[ORM\Id, ORM\GeneratedValue, ORM\Column]
    private ?int $id = null;
    #[ORM\Column(length: 180)]
    #[Assert\NotBlank, Assert\Email]
    private string $authorEmail = '';
    #[ORM\Column]
    private ?\DateTimeImmutable $openedAt = null;
    #[ORM\Column(nullable: true)]
    private ?\DateTimeImmutable $closedAt = null;
    #[ORM\Column(type: 'text')]
    #[Assert\NotBlank]
    #[Assert\Length(min: 20, max: 250, minMessage: 'La description doit contenir au moins {{ limit }} caractères.', maxMessage: 'La description ne peut pas dépasser {{ limit }} caractères.')]
    private string $description = '';
    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'RESTRICT')]
    #[Assert\NotNull]
    private ?Category $category = null;
    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false, onDelete: 'RESTRICT')]
    #[Assert\NotNull]
    private ?TicketStatus $status = null;
    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: true, onDelete: 'SET NULL')]
    private ?User $assignee = null;

    public function getId(): ?int { return $this->id; }
    public function getAuthorEmail(): string { return $this->authorEmail; }
    public function setAuthorEmail(string $email): static { $this->authorEmail = mb_strtolower(trim($email)); return $this; }
    public function getOpenedAt(): ?\DateTimeImmutable { return $this->openedAt; }
    public function setOpenedAt(\DateTimeImmutable $date): static { $this->openedAt = $date; return $this; }
    public function getClosedAt(): ?\DateTimeImmutable { return $this->closedAt; }
    public function setClosedAt(?\DateTimeImmutable $date): static { $this->closedAt = $date; return $this; }
    public function getDescription(): string { return $this->description; }
    public function setDescription(string $description): static { $this->description = trim($description); return $this; }
    public function getCategory(): ?Category { return $this->category; }
    public function setCategory(?Category $category): static { $this->category = $category; return $this; }
    public function getStatus(): ?TicketStatus { return $this->status; }
    public function setStatus(?TicketStatus $status): static { $this->status = $status; return $this; }
    public function getAssignee(): ?User { return $this->assignee; }
    public function setAssignee(?User $assignee): static { $this->assignee = $assignee; return $this; }
}
