<?php

namespace App\DataFixtures;

use App\Entity\Category;
use App\Entity\Ticket;
use App\Entity\TicketStatus;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        $categories = [];
        foreach (['Incident', 'Panne', 'Evolution', 'Anomalie', 'Information'] as $name) {
            $category = (new Category())->setName($name);
            $manager->persist($category);
            $categories[$name] = $category;
        }

        $statuses = [];
        foreach ([['Nouveau', false], ['Ouvert', false], ['Résolu', false], ['Fermé', true]] as [$name, $closed]) {
            $status = (new TicketStatus())->setName($name)->setClosed($closed);
            $manager->persist($status);
            $statuses[$name] = $status;
        }

        $sample = (new Ticket())
            ->setAuthorEmail('client@example.test')
            ->setDescription('Depuis ce matin, je ne parviens plus à accéder à mon espace client. Un message indique une erreur après la connexion.')
            ->setCategory($categories['Incident'])
            ->setStatus($statuses['Nouveau'])
            ->setOpenedAt(new \DateTimeImmutable('-2 hours'));
        $manager->persist($sample);
        $manager->flush();
    }
}
